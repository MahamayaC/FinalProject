package Mahamaya.CertificationProject1;

import java.io.File;
import java.io.FileInputStream;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

public  class ExcelLib {
	public static String data;
	public static String getExcelData( String sheetName, int rowNum, int cellNum)throws Exception
	{
		File filePath=new File("..\\CertificationProject1\\TestData\\Demoblaze_TestcaseSheet1.xls");
		FileInputStream fis=new FileInputStream(filePath);
		HSSFWorkbook workbook = new HSSFWorkbook(fis);
		HSSFSheet sheet = workbook.getSheet(sheetName);
		HSSFRow row = sheet.getRow(rowNum);
		data =row.getCell(cellNum).getStringCellValue();
		
		return data;
	}
		
}