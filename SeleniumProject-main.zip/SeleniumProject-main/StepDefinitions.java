package stepDefinition;



import java.time.Duration;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import Mahamaya.CertificationProject1.Constants;
import Mahamaya.CertificationProject1.DriverScript;

import Mahamaya.CertificationProject1.PageObject;
import Mahamaya.CertificationProject1.Screenshot;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StepDefinitions extends PageObject{
	public static WebDriver driver=null;
	Alert alert;
	String alertMessage=null;
	String demoblazeUrl=null;
	
	//Test case1 implementation starts here
	@Test
	@Given("The user is on webBrowser")
	public void getWebBrowser() {
		
		//Launching empty browser
		driver=DriverScript.driver;
		
		
	}
	
	@Test
	@When("Open the Google browser")
	public void open_the_google_browser() {
		
		//Opening google Url
		driver.get(Constants.url1);		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(Constants.globalWait)); 		
		driver.manage().window().maximize();
	}
	
	@Test
	@Then("Validate user is on google homepage")
	public void validate_user_is_on_google_homepage() throws Exception {
		//Printing google page Url
	    System.out.println("User is on "+driver.getCurrentUrl());
	    Thread.sleep(3000);	
	    }

	//Test case 2 implementation starts here
	@Test
	@Given("User is on Google HomePage")
	public void user_is_on_google_home_page() throws Exception {
		
		//Validating User is on Google Homepage
		 System.out.println("User is on "+driver.getCurrentUrl()); 
		 Screenshot.takeScreenShot(DriverScript.driver, "..\\CertificationProject1\\src\\test\\java\\Screenshots");
	}
	
	@Test
	@When("Enter the DemoBlazeWebsiteURL")
	public void enter_the_demo_blaze_website_url(String url)  {
		driver.findElement(By.xpath("//textarea[@name='q']")).sendKeys(url);
	}
	
	@Test
	@Then("It should generate the list of Related Sites")
	public void it_should_generate_the_list_of_related_sites() throws Exception {
		
	   //User is on google suggestions page
		driver.findElement(By.xpath("//div[@class='FPdoLc lJ9FBc']//input[@value='Google Search']")).submit();
		Thread.sleep(3000);
		System.out.println("List of suggestions generated");
		System.out.println("User is on "+driver.getCurrentUrl());
	}
	
	//Test case 3 impementation code starts here
	@Test
	@Given("list of Related Sites is generated")
	public void list_of_related_sites_is_generated() throws Exception {
		
	    //Checking precondition that user is on google showing list of related sites
		System.out.println("User is on "+driver.getCurrentUrl());
		 Screenshot.takeScreenShot(DriverScript.driver, "..\\CertificationProject1\\src\\test\\java\\Screenshots");
	}
	
	@Test
	@When("click on first suggetion")
	public void click_on_first_suggetion() {
		
		//Clicling on 1st related site
		PageObject.firstSuggestion.click();   
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(Constants.globalWait));
	}
	
	@Test
	@Then("validate user sucessfully Navigated to Demo_blaze Home Page")
	public void validate_user_sucessfully_navigated_to_demo_blaze_home_page() {
	    
		//validating user sucessfully Navigated to Demo_blaze Home Page
		System.out.println("User Navigated to  "+driver.getCurrentUrl());
	}
	
	@Test
	@Then("Sign Up for DemoBlaze Website")
	public void sign_up_for_demo_blaze_website() throws Exception {
	   
		//Clicking on Sign Up link
		PageObject.signUp.click();
		
		//Entering Username 
		PageObject.Username.sendKeys("Mahamaya");
		//Entering Password
		Thread.sleep(2000);
		PageObject.password.sendKeys("password");
		Thread.sleep(2000);
		//Clicking on Sign Up Button
		PageObject.submit.click();;
		Thread.sleep(3000);
		
		//Alert generated. Switching focus to alert
		alert=driver.switchTo().alert();
		//Getting the alert text
		alertMessage=alert.getText();
		System.out.println("Alert Message is :"+alertMessage);
		//if user is already registered click on cancle button
		if(alertMessage.equalsIgnoreCase(Constants.alertMsg1))
		{
			alert.accept();
			PageObject.closeButton.click();
			System.out.println("Alert accepted");
		}
		else
		{
			PageObject.signUp.click();
		}
	}
	@Test
	@Then("validate user is successfully registered")
	public void validate_user_is_successfully_registered() throws Exception {
	    System.out.println("Alert Message is "+alertMessage);
	    Screenshot.takeScreenShot(DriverScript.driver, "..\\CertificationProject1\\src\\test\\java\\Screenshots");
	}

	//Test case 4 implementation code starts here to check login functionality
	@Test
	@Given("User is on Demoblaze Homepage")
	public void user_is_on_demoblaze_homepage() {
		//Checking user is on DemoBlaze homepage
	    System.out.println("User is on "+driver.getCurrentUrl());
	}
	
	@Test
	@When("Login to DemoBlaze account")
	public void login_to_demo_blaze_account() throws Exception {
		
		//Clicking on Login link
		PageObject.login.click();
		// entering  username
		PageObject.loginUser.sendKeys("Mahamaya");
		Thread.sleep(2000);		
		//entering password
		PageObject.loginPass.sendKeys("password");
		Thread.sleep(2000);
		//clicking on login button
		PageObject.loginButton.click();
		Thread.sleep(3000);
		System.out.println("User Logged In successfully");
		String u1=driver.getCurrentUrl();
		System.out.println("User is on Url "+u1);
		//Alert generated. Switching focus to alert
		if(u1.equalsIgnoreCase(Constants.url2))
		{
			System.out.println("User Logged In successfully");
		}
		//if user is already registered click on cancle button
		else
		{
			alert=driver.switchTo().alert();
			//Getting the alert text
			alertMessage=alert.getText();
			System.out.println("Alert Message is "+alertMessage);
			alert.accept();
			PageObject.loginCloseButton.click();
			
		}
				
	}
	@Test
	@Then("validate greeting message")
	public void validate_greeting_message() throws Exception {
		//validating greeting message
	   System.out.println("Greeting Message is displayed ");
	   Thread.sleep(3000);
	   Screenshot.takeScreenShot(DriverScript.driver, "..\\CertificationProject1\\src\\test\\java\\Screenshots");
	}
	
	
	@Test
	@Then("close the browser")
	public void close_the_browser()
	{
		//closing the active browser window
		driver.close();
	}
}
