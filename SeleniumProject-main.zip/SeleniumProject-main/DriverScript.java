package Mahamaya.CertificationProject1;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.safari.SafariDriver;

public class DriverScript {
	
	public static WebDriver driver=null;

	public static  WebDriver getBrowser(String browser)
	{
		if(Constants.browser.equalsIgnoreCase(browser))
		{
			System.setProperty("webdriver.chrome.driver", Constants.driverpath);
			driver=new ChromeDriver();
		}
		else if(Constants.browser1.equalsIgnoreCase(browser))
		{
			System.setProperty("webdriver.gecko.driver", Constants.driverpath1);
			driver=new FirefoxDriver();
		}
		else if(Constants.browser2.equalsIgnoreCase(browser))
		{
			System.setProperty("webdriver.safari.driver", Constants.driverpath2);
			driver=new SafariDriver();
		}
		else if(Constants.browser3.equalsIgnoreCase(browser))
		{
			System.setProperty("webdriver.ie.driver", Constants.driverpath3);
			driver=new InternetExplorerDriver();
		} 
	return driver;
	}

}
