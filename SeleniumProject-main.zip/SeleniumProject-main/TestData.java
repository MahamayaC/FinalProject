package Mahamaya.CertificationProject1;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import stepDefinition.StepDefinitions;
@Test
public class TestData {
	
	public static WebDriver driver=null;
	@Test
	public void Demo_blazeTest() throws Exception
{
		//Argument passed will decide which browser to invoke
	 driver= DriverScript.getBrowser("chrome");
	 StepDefinitions sd=PageFactory.initElements(driver, StepDefinitions.class);
	 //Test case 1 method invocation
	 sd.getWebBrowser();
	 sd.open_the_google_browser();
	 sd.validate_user_is_on_google_homepage();
	 sd.user_is_on_google_home_page();
	 
	//Test case 2 method invocation 
	 String url=ExcelLib.getExcelData("Demoblaze_TestcaseSheet1", 1, 6);
	 sd.enter_the_demo_blaze_website_url(url);
	// sd.enter_the_demo_blaze_website_url();
	 sd.it_should_generate_the_list_of_related_sites();
	 
	//Test case 3 method invocation
	 sd.list_of_related_sites_is_generated();	
	 sd.click_on_first_suggetion();
	 sd.validate_user_sucessfully_navigated_to_demo_blaze_home_page();
	 sd.sign_up_for_demo_blaze_website();	 
	 sd.validate_user_is_successfully_registered();
	 
	//Test case 4 method invocation
	 sd.user_is_on_demoblaze_homepage();
	 sd.login_to_demo_blaze_account();
	 sd.validate_greeting_message();
	 sd.close_the_browser();
}

}

