package Mahamaya.CertificationProject1;

import java.io.File;
public interface Constants {
	
	String browser="Chrome";
	String browser1="Firefox";
	String browser2="Safari";
	String browser3="Internet Exporer";
	String url1 ="https://www.google.com/";
	String url3="https://www.demoblaze.com";
	String url2="https://demoblaze.com/";
	
	String alertMsg1="This user already exist.";
		
	String driverpath="..\\CertificationProject1\\Driver\\chromedriver.exe";
	String driverpath1="..\\CertificationProject1\\Driver\\geckodriver.exe";
	String driverpath2="..\\CertificationProject1\\Driver\\selenium-safari-driver-2.29.1-sources.jar";
	String driverpath3="..\\CertificationProject1\\Driver\\IEDriverServer.exe";
	File filepath = new File("..\\CertificationProject1\\TestData\\Demoblaze_TestcaseSheet1.xls");
	int globalWait=30;
	String alertMsg = "Sign up successful.";
	String alertMsg2 = "Wrong Password.";
	

	
}
