package Mahamaya.CertificationProject1;


import java.io.File;
import java.io.IOException;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class Screenshot {

	public static void takeScreenShot(WebDriver driver,String fileWithPath) throws IOException
	{
		 Date d = new Date();
		 System.out.println(d.toString());
		 SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss"); 
	File scrFile = ((TakesScreenshot)DriverScript.driver).getScreenshotAs(OutputType.FILE);
    FileUtils.copyFile(scrFile,  new File("..\\CertificationProject1\\src\\test\\java\\Screenshots\\screenshot"+sdf.format(d)+".png"));
}
}



