package testRunner;

import io.cucumber.testng.CucumberOptions;

@CucumberOptions(
features = "src/test/java/features",
glue="src/test/java/stepDefinition"
)
public class TestNGTestRunner {
	

}
