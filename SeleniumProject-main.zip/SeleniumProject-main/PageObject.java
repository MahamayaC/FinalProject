package Mahamaya.CertificationProject1;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class PageObject {
	
	public static WebDriver driver=null;
	
/*	 //capturing the object Google search textfield
	  @FindBy(xpath="//textarea[@id='APjFqb']")
	  public static WebElement googleSearchTextfield;
*/	  
	  
	  //capturing the object Google search textfield
	  @FindBy(xpath="//textarea[@name='q']")
	  public static WebElement googleSearch;
	  
	  //capturing the object Google Search Button
	  @FindBy(xpath="//div[@class='FPdoLc lJ9FBc']//input[@value='Google Search']")
	  public static WebElement googleSearchButton;
	  
	//capturing the object Username
	  @FindBy(xpath="//input[@id='sign-username']")
	  public static WebElement Username;
	 	  
	  //capturing the object password 
	  @FindBy(xpath="//input[@id='sign-password']")
	  public static WebElement password;
	  
	  //capturing the object Sign In button textfield
	  @FindBy(xpath="//button[@onclick='register()']")
	  public static WebElement submit;
	  
	 
	  	  
	 //capturing the object Google Search First Suggestion link
	 @FindBy(xpath="//h3[contains(text(),'the Demo Blaze')]")
	 public static WebElement firstSuggestion;

	 //capturing the object Sign Up
	@FindBy(xpath="//a[@id='signin2']")
	public static WebElement signUp;
	
	//capturing the object Log In
	@FindBy(xpath="//a[@id='login2']")
	public static WebElement login;
	
	//capturing the object LoginUsername
	@FindBy(xpath="//input[@id='loginusername']")
	public static WebElement loginUser;
	
	//capturing the object LoginPassword
	@FindBy(xpath="//input[@id='loginpassword']")
	public static WebElement loginPass;
	

	//capturing the object LoginButton
	@FindBy(xpath="//button[@onclick='logIn()']")
	public static WebElement loginButton;
	

	//capturing the object close button
	@FindBy(css="#signInModal>div>div>div.modal-footer>button.btn.btn-secondary")
	public static WebElement closeButton;
	
	//capturing the object Login close button
		@FindBy(css="#logInModal > div > div > div.modal-footer > button.btn.btn-secondary")
		public static WebElement loginCloseButton;
	
	

	//capturing the object welcome message
	@FindBy(xpath="//a[@id='nameofuser']")
	public static WebElement welcomemsg;
	
			
}
